# fuelxpress_orders/forms.py
from django import forms
from .models import FuelXpressOrder

class FuelXpressOrderForm(forms.ModelForm):
    class Meta:
        model = FuelXpressOrder
        fields = ['FX_fuel_type', 'FX_quantity', 'FX_cost', 'FX_delivery_location']

    def __init__(self, *args, **kwargs):
        super(FuelXpressOrderForm, self).__init__(*args, **kwargs)
        self.fields['FX_fuel_type'].widget = forms.Select(choices=[('Petrol', 'Petrol'), ('Diesel', 'Diesel')], attrs={'class': 'form-control'})
        self.fields['FX_quantity'].widget.attrs.update({'class': 'form-control'})
        self.fields['FX_delivery_location'].widget.attrs.update({'class': 'form-control'})
