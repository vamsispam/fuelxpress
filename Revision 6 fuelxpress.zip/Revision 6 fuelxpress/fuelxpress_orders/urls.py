from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.fuelxpress_create_order, name='fuelxpress_create_order'),
    path('<int:order_id>/', views.fuelxpress_order_detail, name='fuelxpress_order_detail'),
    path('list/', views.fuelxpress_order_list, name='fuelxpress_order_list'),
    path('payment/<int:order_id>/', views.fuelxpress_order_payment, name='fuelxpress_order_payment'),
    path('process_payment/<int:order_id>/', views.process_payment, name='process_payment'), 
    path('payment_success/<int:order_id>/', views.payment_success, name='payment_success'),
]
