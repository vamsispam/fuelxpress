from django.shortcuts import render, redirect
from .forms import FuelXpressOrderForm
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import FuelXpressPayment, FuelXpressOrder
from django.http import HttpResponse
from django.views.decorators.http import require_POST

@login_required
def fuelxpress_create_order(request):
    if request.method == 'POST':
        form = FuelXpressOrderForm(request.POST)
        if form.is_valid():
            fuelxpress_order = form.save(commit=False)
            fuelxpress_order.FX_user = request.user  # Set the user associated with the order
            fuelxpress_order.save()
            return redirect('fuelxpress_order_payment', order_id=fuelxpress_order.pk)
    else:
        form = FuelXpressOrderForm()
    return render(request, 'fuelxpress_orders/fuelxpress_order_create.html', {'form': form})

@login_required
def fuelxpress_order_detail(request, order_id):
    order = get_object_or_404(FuelXpressOrder, pk=order_id)
    return render(request, 'fuelxpress_orders/fuelxpress_order_detail.html', {'order': order})

@login_required
def fuelxpress_order_list(request):
    orders = FuelXpressOrder.objects.filter(FX_user=request.user).order_by('-FX_order_date')
    return render(request, 'fuelxpress_orders/fuelxpress_order_list.html', {'orders': orders})

@login_required
def fuelxpress_order_payment(request, order_id):
    order = get_object_or_404(FuelXpressOrder, pk=order_id)
    # Add payment handling logic here, process the payment, update order status, etc.
    return render(request, 'fuelxpress_orders/fuelxpress_order_payment.html', {'order': order})

@require_POST
def process_payment(request, order_id):
    order = get_object_or_404(FuelXpressOrder, pk=order_id)
    
    # Check if a payment already exists for this order
    existing_payment = FuelXpressPayment.objects.filter(order=order).exists()
    if existing_payment:
        return HttpResponse("Payment already processed for this order")
    
    # Extract payment details from the form submission
    amount_paid = request.POST.get('amount_paid')
    payment_method = request.POST.get('payment_method')
    
    if payment_method == 'card':
        card_number = request.POST.get('card_number')
        # Process card payment logic
        
    elif payment_method == 'paypal':
        pass
        # Process PayPal payment logic
        
    elif payment_method == 'cash':
        # For cash payment, directly use the amount from the order
        amount_paid = order.FX_cost

    # Validate amount_paid and perform necessary checks
    if amount_paid:
        # Save payment details to FuelXpressPayment model
        payment = FuelXpressPayment.objects.create(
            order=order,
            amount_paid=amount_paid,
            payment_method=payment_method,
        )

        # Update the order's is_paid field to True
        order.is_paid = True
        order.save()

        return redirect('payment_success', order_id=order.id)
    else:
        return HttpResponse("Invalid payment details")

@login_required
def payment_success(request, order_id):
    order = get_object_or_404(FuelXpressOrder, pk=order_id)
    return render(request, 'fuelxpress_orders/payment_success.html', {'order': order})
