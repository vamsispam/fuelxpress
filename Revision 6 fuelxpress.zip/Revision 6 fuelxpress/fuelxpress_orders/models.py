from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from fuelxpress_gasstations.models import FuelXpressGasStation
from fuelxpress_drivers.models import FuelXpressDriver
from django.urls import reverse

class FuelXpressOrder(models.Model):
    PENDING = 'Pending'
    PROCESSING = 'Processing'
    DELIVERED = 'Delivered'
    REJECTED = 'Rejected'

    ORDER_STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (PROCESSING, 'Processing'),
        (DELIVERED, 'Delivered'),
        (REJECTED, 'Rejected'),
    ]

    FX_user = models.ForeignKey(User, on_delete=models.CASCADE)
    FX_gas_station = models.ForeignKey(FuelXpressGasStation, on_delete=models.CASCADE, blank=True, null=True, related_name='orders_assigned')  
    FX_driver = models.ForeignKey(FuelXpressDriver, on_delete=models.CASCADE, blank=True, null=True)  
    FX_fuel_type = models.CharField(max_length=100)
    FX_quantity = models.DecimalField(max_digits=10, decimal_places=2)
    FX_cost = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    FX_delivery_location = models.CharField(max_length=100)
    FX_order_status = models.CharField(max_length=50, choices=ORDER_STATUS_CHOICES, default=PENDING)
    FX_order_date = models.DateTimeField(default=timezone.now)
    is_paid = models.BooleanField(default=False)

    def __str__(self):
        return f"Order for {self.FX_user.username}"

class FuelXpressPayment(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Cash'),
        ('paypal', 'PayPal'),
        ('card', 'Card'),
    ]

    order = models.OneToOneField(FuelXpressOrder, on_delete=models.CASCADE, related_name='payment')
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2)
    payment_date = models.DateTimeField(auto_now_add=True)
    payment_method = models.CharField(max_length=10, choices=PAYMENT_METHOD_CHOICES)

    def __str__(self):
        return f"Payment for Order ID: {self.order.id}"

        