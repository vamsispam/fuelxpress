# fuelxpress_orders/utils.py
from geopy.distance import geodesic
from fuelxpress_gasstations.models import FuelXpressGasStation
from fuelxpress_drivers.models import FuelXpressDriver

def find_nearest_gas_station(delivery_location):
    gas_stations = FuelXpressGasStation.objects.all()
    delivery_point = get_coordinates(delivery_location)

    # Find the nearest gas station
    nearest_gas_station = min(gas_stations, key=lambda station: geodesic(get_coordinates(station.location), delivery_point).miles)

    return nearest_gas_station

def find_nearest_driver(delivery_location):
    drivers = FuelXpressDriver.objects.all()
    delivery_point = get_coordinates(delivery_location)

    # Find the nearest driver
    nearest_driver = min(drivers, key=lambda driver: geodesic(get_coordinates(driver.location), delivery_point).miles)

    return nearest_driver

def get_coordinates(location):
    # Parse location to get latitude and longitude
    coordinates = location.split(',')
    if len(coordinates) == 2:
        latitude, longitude = coordinates
        return float(latitude), float(longitude)
    else:
        # Handle the case where the location format is incorrect
        # You can raise an exception, return a default value, or handle it as appropriate for your application
        return 0.0, 0.0  # Default coordinates
