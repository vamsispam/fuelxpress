from django.contrib import admin
from .models import FuelXpressOrder, FuelXpressPayment

# Register your models here.
admin.site.register(FuelXpressOrder)
admin.site.register(FuelXpressPayment)
