from django.shortcuts import render, get_object_or_404
from django.contrib.auth.models import User

def fuelxpress_index(request):
    return render(request, 'fuelxpress_dashboard/fuelxpress_index.html')

def fuelxpress_home(request):
    return render(request, 'fuelxpress_dashboard/fuelxpress_home.html')

def fuelxpress_about(request):
    return render(request, 'fuelxpress_dashboard/fuelxpress_about.html')
