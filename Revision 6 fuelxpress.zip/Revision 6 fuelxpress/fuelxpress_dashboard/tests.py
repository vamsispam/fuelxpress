from django.test import TestCase
from django.urls import reverse

class DashboardViewsTests(TestCase):
    def test_fuelxpress_index_view(self):
        response = self.client.get(reverse('fuelxpress_index'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'fuelxpress_dashboard/fuelxpress_index.html')

    def test_fuelxpress_home_view(self):
        response = self.client.get(reverse('fuelxpress_home'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'fuelxpress_dashboard/fuelxpress_home.html')

    def test_fuelxpress_about_view(self):
        response = self.client.get(reverse('fuelxpress_about'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'fuelxpress_dashboard/fuelxpress_about.html')
