from django.urls import path
from . import views

urlpatterns = [
    path('', views.fuelxpress_index, name='fuelxpress_index'),
    path('home/', views.fuelxpress_home, name='fuelxpress_home'),
    path('about/', views.fuelxpress_about, name='fuelxpress_about'),
]
