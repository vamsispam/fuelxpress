# FuelXpress - Online Fuel Delivery

FuelXpress is an online fuel delivery web application that offers a convenient way to have fuel delivered to your location. With a user-friendly interface and essential features, we aim to make fueling as simple as a few clicks.

## Demo

- **Admin Login**: admin
- **Password**: 1234

## Features

- **User Registration and Authentication**: Users can create accounts and log in securely.

- **Order Fuel**: Place fuel orders with details like fuel type, quantity, and delivery location.

- **Track Orders**: Monitor the status of your orders and get estimated delivery times.

- **Gas Station Management**: Gas station owners can register, manage inventory, and process orders.

- **Driver Assignment**: Assign drivers to orders for efficient delivery.

- **Payment Processing**: Secure payment processing through various options.

- **Route Optimization**: Optimize delivery routes for faster service.

- **Data Security and Privacy**: Ensuring the protection of user data and privacy.

## Modules Used

- **Django**: The core web framework used for building the application.

- **Crispy-Bootstrap4**: For easy and elegant form rendering.

- **Pillow**: A Python Imaging Library that is used for image processing.

- **Python-Decouple**: To separate configuration settings from the source code.

## Getting Started

1. Clone the repository to your local machine.
   
2. Create a virtual environment and install the required packages:

   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows, use 'venv\Scripts\activate'
   pip install -r requirements.txt
   ```

3. Apply migrations to create the database:

   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

4. Run the development server:

   ```bash
   python manage.py runserver
   ```

5. Access the admin panel with the provided credentials to manage the application:

   - **Admin URL**: http://localhost:8000/admin/
   - **Username**: admin
   - **Password**: 1234

6. Run Tests

   ```bash
   python manage.py test fuelxpress_dashboard
   python manage.py test fuelxpress_gasstations
   python manage.py test fuelxpress_orders
   python manage.py test users
   python manage.py test fuelxpress_drivers
   ```

5. Access the gas station panel with the provided credentials to manage the application:

   - **Admin URL**: http://localhost:8000/admin/
   - **Username**: GasStation1
   - **Password**: 1234fuel

   - **Admin URL**: http://localhost:8000/admin/
   - **Username**: GasStation2
   - **Password**: 1234fuel