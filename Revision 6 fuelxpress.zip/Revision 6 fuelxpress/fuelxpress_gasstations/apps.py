from django.apps import AppConfig


class FuelxpressGasstationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fuelxpress_gasstations'
