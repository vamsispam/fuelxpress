from django.contrib import admin
from .models import FuelXpressGasStation

# Register your models here.
admin.site.register(FuelXpressGasStation)
