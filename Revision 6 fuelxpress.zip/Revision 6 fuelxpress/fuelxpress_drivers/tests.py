from django.test import TestCase
from .models import FuelXpressDriver

class DriverModelTests(TestCase):
    def setUp(self):
        self.driver = FuelXpressDriver(
            FX_name="John Doe",
            FX_license_number="ABC123",
            FX_phone_number="555-555-5555",
            FX_email="johndoe@example.com",
            FX_availability=True,
        )

    def test_driver_creation(self):
        """Test that a driver is correctly created."""
        self.assertEqual(self.driver.FX_name, "John Doe")
        self.assertEqual(self.driver.FX_license_number, "ABC123")
        self.assertEqual(self.driver.FX_phone_number, "555-555-5555")
        self.assertEqual(self.driver.FX_email, "johndoe@example.com")
        self.assertTrue(self.driver.FX_availability)

    def test_driver_str_method(self):
        """Test the __str__ method of the Driver model."""
        expected_str = "John Doe"
        self.assertEqual(str(self.driver), expected_str)

    def test_default_availability(self):
        """Test that the availability field defaults to True."""
        driver = FuelXpressDriver.objects.create(
            FX_name="Jane Smith",
            FX_license_number="XYZ789",
            FX_phone_number="555-555-5556",
            FX_email="janesmith@example.com",
        )
        self.assertTrue(driver.FX_availability)
