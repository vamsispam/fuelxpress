from django.shortcuts import render
from .models import FuelXpressDriver

def fuelxpress_driver_list(request):
    drivers = FuelXpressDriver.objects.all()
    return render(request, 'fuelxpress_drivers/fuelxpress_driver_list.html', {'drivers': drivers})
