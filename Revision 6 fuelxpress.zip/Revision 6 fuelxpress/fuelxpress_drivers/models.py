from django.db import models

# Create your models here.
class FuelXpressDriver(models.Model):
    FX_name = models.CharField(max_length=100)
    FX_license_number = models.CharField(max_length=20)
    FX_phone_number = models.CharField(max_length=100)
    FX_email = models.EmailField()
    FX_availability = models.BooleanField(default=True)

    def __str__(self):
        return self.FX_name