from django.urls import path
from . import views

urlpatterns = [
    path('drivers/', views.fuelxpress_driver_list, name='fuelxpress_driver_list'),
    # Add more URL patterns for other views as needed
]
